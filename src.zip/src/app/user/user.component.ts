import { Component, OnInit, Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  @Output() featureSelected = new EventEmitter<string>();
  onSelect(feature: string) {
    this.featureSelected.emit(feature);
  }

  welcome : string;
  names : any
  constructor(){
      this.welcome = "Users"

      this.names = [{
          FirstName : "John",
          LastName: "Smith",
          PhoneNumber : "9897654987",
          email : "2000sandeep77@gmail.com",
          dob : "7/7/2000"
          
      },
      {
        FirstName : "John",
        LastName: "Smith",
        PhoneNumber : "9897654987",
        email : "2000sandeep77@gmail.com",
        dob : "7/7/2000"
        
    },
    {
      FirstName : "John",
      LastName: "Smith",
      PhoneNumber : "9897654987",
      email : "2000sandeep77@gmail.com",
      dob : "7/7/2000"
      
  },
  {
    FirstName : "John",
    LastName: "Smith",
    PhoneNumber : "9897654987",
    email : "2000sandeep77@gmail.com",
    dob : "7/7/2000"
    
},
{
  FirstName : "John",
  LastName: "Smith",
  PhoneNumber : "9897654987",
  email : "2000sandeep77@gmail.com",
  dob : "7/7/2000"
  
}]
  };

  ngOnInit() {
  }

  
}