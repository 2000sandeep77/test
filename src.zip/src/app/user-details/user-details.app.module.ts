export class User {
  constructor(public imagePath:string,public title:string,public firstName: string, public lastName: string,public phone:string,public mobile:string,public street:string,public city:string,public state:string,public email:string,public dob:string ){
  }
}