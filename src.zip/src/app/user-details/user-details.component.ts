import { Component, OnInit } from '@angular/core';
import { User } from './user-details.app.module';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {
  users : User[] = [
    new User('https://www.freepngimg.com/thumb/ryan_gosling/31253-3-ryan-gosling-transparent-background.png','Mr','John','Smith','7e587054','7538763','lian terace','noida','UP','2000s','7/7/2000')
  ];

  constructor() { }

  ngOnInit() {
  }

}
